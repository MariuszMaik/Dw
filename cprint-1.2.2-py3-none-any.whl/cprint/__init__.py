# coding: utf8
#!/usr/bin/env python
from .cprint import *

"""
    This module give to possibility to print in color.
"""

__version__ = "1.2.2"
